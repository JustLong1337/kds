# Kitchen Display System (KDS) - Member 2

## Overview
Real-time Kitchen Display System for SmartBistro.

## Features
- Priority queue based on preparation time
- Real-time status updates
- Dietary requirements highlighting
- Responsive modern UI

## How to Run
1. Open terminal in `kds` folder
2. `npm init -y`
3. `npm install express`
4. `node server.js`
5. Open browser → http://localhost:3000

## Files
- `public/index.html` - Main UI
- `public/style.css` - Styling
- `public/app.js` - Frontend logic